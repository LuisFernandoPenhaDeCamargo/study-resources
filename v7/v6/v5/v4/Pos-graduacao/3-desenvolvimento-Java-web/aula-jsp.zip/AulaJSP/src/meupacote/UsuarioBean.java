package meupacote;

public class UsuarioBean {
	
	private String usuario;
	
	public UsuarioBean() {
		usuario = "";
	}

	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String u) {
		usuario = u;
	}
}
